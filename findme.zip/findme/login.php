<?php
$email_error=null;
$password_error=null;
session_start();
if(isset($_POST['login'])){
    $email=$_POST['email'];
    $password=$_POST['password'];
    if( $email==""){
        $email_error="Email is blank";
    } 
    else if($password == ""){
        
            $password_error="Password is blank";
    }
        
        else{
            include("dbconnect.php");
            $sql = "SELECT * from registration where email='$email' and pass='$password'";
            $retval = mysqli_query($conn ,$sql);
            if(mysqli_num_rows($retval)>0){
                header('location:home.php');
                $_SESSION["email"] = $email;

                exit();

            }
            else{
                $login_error = "Login failed";

            }
mysqli_close($conn);
        }
    }
        ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Find Me</title>
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<link rel="stylesheet" href="./css/styles.css">
<script src="./script/logscript.js"></script>
<script src="./script/form-validation.js"></script>
<link rel="stylesheet" href="./css/style.css">
<?php
if($email_error!=null){?> <style>.error{display: block;}</style>  <?php }
if($password_error!=null){?> <style>.error{display: block;}</style>  <?php }
?>
</head>
<body>

<div class="container">

<div class="row" style="margin-top:20px">
    <div class="col-xs-12 col-sm-8 col-md-6 col-sm-offset-2 col-md-offset-3">
		<form role="form" id="form" action="" method="post">
			<fieldset>
				<h2>Find Me - Login</h2>
				<hr class="colorgraph">
				<div class="form-group">
                    <p><input type="email" name="email" id="email" class="form-control input-lg" placeholder="Email Address"></p>
                    <span class="error"><?php echo $email_error; ?></span>
				</div>
				<div class="form-group">
                <p>    <input type="password" name="password" id="password" class="form-control input-lg" placeholder="Password"></p>
                <span class="error"><?php echo $password_error; ?></span>
				</div>
				<span class="button-checkbox">
					<button type="button" class="btn" data-color="info">Remember Me</button>
                    <input type="checkbox" name="remember_me" id="remember_me" checked="checked" class="hidden">
					<a href="" class="btn btn-link pull-right">Forgot Password?</a>
				</span>
				<hr class="colorgraph">
				<div class="row">
					<div class="col-xs-6 col-sm-6 col-md-6">
                        <input type="submit" class="btn btn-lg btn-success btn-block" value="Sign In" name="login">
					</div>
					<div class="col-xs-6 col-sm-6 col-md-6">
						<a href="./index.php" class="btn btn-lg btn-primary btn-block">Register</a>
					</div>
				</div>
			</fieldset>
		</form>
	</div>
</div>

</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>

</body>
</html>
