<?php
include("dbconnect.php");
$email=$_GET['email'];  

$sql = "Update registration set status = 0 where email='$email'";
mysqli_query($conn,$sql);
mysqli_close($conn);

session_destroy();
header('location:login.php');
exit();
?>