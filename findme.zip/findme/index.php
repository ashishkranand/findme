<?php

include("dbconnect.php");

$success=null;
$reg_error=null;
$regg_error=null;

if(isset($_POST['register'])){
    $fname=$_POST['fname'];
    $lname=$_POST['lname'];
    $email=$_POST['email'];
    $phone=$_POST['phone'];
    $gender=$_POST['gender'];
    $city=$_POST['city'];
    $country=$_POST['country'];
    $password=$_POST['password'];
    $latt=$_POST['latval'];
    $longg=$_POST['longval'];
    // echo $password;
    // die;
    

            $sql = "SELECT * from registration where email='$email' or phone='$phone' ";
            $retval = mysqli_query($conn ,$sql);
            if(mysqli_num_rows($retval)>0){
                $regg_error="Sorry your email or phone is already registered.";
            }
            else{
                $filename = $_FILES["uploadfile"]["name"];
                $filename = time().$filename;
                $tempname = $_FILES["uploadfile"]["tmp_name"];
                $folder = './image/' . $filename;
             
                // include("dbconnect.php");
             
                // Get all the submitted data from the form
                // $sql = "update registration set filename='$filename' where email='$user'";
                // $sql = "INSERT INTO registration (filename) VALUES ('$filename') where email= '$user'";
            
                // Execute query
                // mysqli_query($conn, $sql);
            
             
                // Now let's move the uploaded image into the folder: image
                if (move_uploaded_file($tempname, $folder)) {
                    $success="Registration successful, now you can login by clicking on log in button";
                } else {
                    $reg_error="Registration Failed, Try again";
                }
                $pword=$_POST['password'];
$sql = "Insert into registration (fname,lname,email,phone,gender,city,country,pass,latti,longi,filename) VALUES
('$fname','$lname','$email','$phone','$gender','$city','$country','$pword','$latt','$longg','$filename')";
    if(mysqli_query($conn,$sql)){
        $success="Registration successful, now you can login by clicking on log in button";
       
        header('location:home.php');
        $_SESSION["email"] = $email;
        $sql = "Update registration set status = 1 where email='$email'";
        mysqli_query($conn,$sql);
        $fname=null;
        $lname=null;
        $email=null;
        $phone=null;
        $gender=null;
        $city=null;
        $country=null;
        $password=null;
    }
    else{
        $reg_error="Registration Failed, Try again";
    }
mysqli_close($conn);
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Find ME</title>
    <link rel="shortcut icon" href="./image/logo.png" type="image/x-icon">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.8/css/all.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link rel="stylesheet" href="./css/style.css">
<script src=
"https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js">
      </script>
    <script src=
"https://cdn.jsdelivr.net/jquery.validation/1.16.0/jquery.validate.min.js">
      </script>
    <script src=
"https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js">
      </script>
      <script src="./script/form-validation.js"></script>
<?php
if($success!=null){?> <style>.success{display: block;}</style>  <?php }
if($reg_error!=null){?> <style>.error{display: block;}</style>  <?php }
if($regg_error!=null){?> <style>.error{display: block;}</style>  <?php }

?>
<style>
    .error{
        color:red;
        margin-top: 0%;
        display: block;
    }
    .logbtn:hover{
        cursor: pointer;
        outline: 2px solid yellow;
        outline-offset: 4px;
        background-color: darkgreen !important;
        color: white !important;
    }
</style>
</head>
<body onload="myGeolocator()">
<div class="container">
<br>  


<div class="row justify-content-center">
<div class="col-md-6">
<div class="card">
<header class="card-header" style="background-color:darkblue;color:white;">
    <span class="success"><?php echo $success; ?> </span>
    <span class="error"> <?php echo $reg_error; ?> </span>
    <span class="error"> <?php echo $regg_error; ?> </span>
	<a href="./login.php" class="float-right btn btn-outline-primary mt-1 logbtn" style="background-color: lightgreen; color:Black;font-weight:bold;font-size:large;">Log in</a>
	<h4 class="card-title mt-2" ><img src="./image/logo.png" alt="" width="10%" style="border-radius:12px;margin-right:3%;">Find Me - Sign up</h4>
    <p>Your Location: <span id="location"></span></p>

</header>
<article class="card-body">
<form action="" method="post" enctype="multipart/form-data" id="regform">
	<div class="form-row">
		<div class="col form-group">
			<label>First name <span style="color:red">*</span></label>   
		  	<input type="text" class="form-control" name="fname" placeholder="" value="<?php echo $fname; ?>">
            <!-- <span class="fname-error error"><?php echo $fname_error;?></span> -->
		</div> <!-- form-group end.// -->
		<div class="col form-group">
			<label>Last name <span style="color:red">*</span></label>
		  	<input type="text" class="form-control" name="lname" placeholder=" " value="<?php echo $lname; ?>">
              <!-- <span class="lname-error error"><?php echo $lname_error;?></span> -->
		</div> <!-- form-group end.// -->
	</div> <!-- form-row end.// -->
	<div class="form-group">
		<label>Email address <span style="color:red">*</span></label>
		<input type="email" class="form-control" name="email" id="email" placeholder="" value="<?php echo $email; ?>">
        <!-- <span class="email-error error"><?php echo $email_error;?></span> -->
		<small class="form-text text-muted">We'll never share your email with anyone else.</small>
	</div> <!-- form-group end.// -->
    <div class="form-group">
		<label>Phone number <span style="color:red">*</span></label>
		<input type="text" class="form-control" name="phone" id="phone" placeholder="" value="<?php echo $phone; ?>">
        <!-- <span class="email-error error"><?php echo $email_error;?></span> -->
		<small class="form-text text-muted">We'll never share your phone number with anyone else.</small>
	</div> <!-- form-group end.// -->
	<div class="form-group">
            <label>Gender <span style="color:red">*</span></label>
			<label class="form-check form-check-inline">
		  <input class="form-check-input" type="radio" name="gender" value="male">
		  <span class="form-check-label"> Male </span>
		</label>
		<label class="form-check form-check-inline">
		  <input class="form-check-input" type="radio" name="gender" value="female">
		  <span class="form-check-label"> Female</span>
		</label>
        <!-- <span class="gender-error error"><?php echo $gender_error;?></span> -->
	</div> <!-- form-group end.// -->
	<div class="form-row">
		<div class="form-group col-md-6">
		  <label>City <span style="color:red">*</span></label>
		  <input type="text" class="form-control" name="city" value="<?php echo $city; ?>">
          <!-- <span class="city-error error"><?php echo $city_error;?></span> -->
		</div> <!-- form-group end.// -->
		<div class="form-group col-md-6">
		  <label>Country <span style="color:red">*</span></label>
		  <select id="inputState" class="form-control" name="country">
		    <option selected=""></option>
		      <option>Uzbekistan</option>
		      <option>Russia</option>
		      <option>United States</option>
		      <option>India</option>
		      <option>Afganistan</option>
		  </select>
          <!-- <span class="country-error error"><?php echo $country_error;?></span> -->
		</div> <!-- form-group end.// -->
	</div> <!-- form-row.// -->
    <div class="form-group">
		<label>Profile Photo</label>
		<input type="file" class="form-control" name="uploadfile" id="image">
	</div>
	<div class="form-group">
		<label>Create password <span style="color:red">*</span></label>
	    <input class="form-control" type="password" name="password">
        <!-- <span class="password-error error"><?php echo $password_error;?></span> -->
	</div> <!-- form-group end.// --> 
    
    
    <div class="col form-group">
		  	<input type="hidden" class="form-control" name="latval"  id="lat" placeholder="">
		  	<input type="hidden" class="form-control" name="longval"  id="long" placeholder="">
		</div> <!-- form-group end.// -->


    <div class="form-group">
        <!-- <button type="submit" class="btn btn-primary btn-block"> Register  </button> -->
        <input type="submit" value="Register" name="register" class="btn btn-primary btn-block" onclick="getLocation()">
    </div> <!-- form-group// -->      
    <small class="text-muted">By clicking the 'Register' button, you confirm that you accept our <br> Terms of use and Privacy Policy.</small>                                          

</form>
</article> <!-- card-body end .// -->
</div> <!-- card.// -->
</div> <!-- col.//-->

</div> <!-- row.//-->


</div> 
<!--container end.//-->

<script>
      let lat = document.getElementById("lat");
      let longi = document.getElementById("long");
      let userLocation = navigator.geolocation;
      function myGeolocator() {
         if(userLocation) {
            userLocation.getCurrentPosition(success);
         } else {
            "The geolocation API is not supported by your browser.";
         }
      }
      function success(data) {
         let lattitud = data.coords.latitude;
         let longitud = data.coords.longitude;
        //  result.innerHTML = "Latitude: "
        //  + lat
        //  + "<br>Longitude: "
        //  + long;
        lat.value=lattitud;
        longi.value=longitud;
      }
   </script>
   <script>
$(document).ready(function(){
    if(navigator.geolocation){
        navigator.geolocation.getCurrentPosition(showLocation);
    }else{ 
        $('#location').html('Geolocation is not supported by this browser.');
    }
});

function showLocation(position){
    var latitude = position.coords.latitude;
    var longitude = position.coords.longitude;
    $.ajax({
        type:'POST',
        url:'getLocation.php',
        data:'latitude='+latitude+'&longitude='+longitude,
        success:function(msg){
            if(msg){
               $("#location").html(msg);
            }else{
                $("#location").html('Not Available');
            }
        }
    });
}
</script>
</body>
</html>
