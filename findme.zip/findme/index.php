<?php
ini_set('display_errors', 0);
$success=null;
$reg_error=null;
$regg_error=null;
$fname_error=null;
    $lname_error=null;
    $email_error=null;
    $gender_error=null;
    $city_error=null;
    $country_error=null;
    $password_error=null;
if(isset($_POST['register'])){
    $fname=$_POST['fname'];
    $lname=$_POST['lname'];
    $email=$_POST['email'];
    $gender=$_POST['gender'];
    $city=$_POST['city'];
    $country=$_POST['country'];
    $password=$_POST['password'];
    $latt=$_POST['latval'];
    $longg=$_POST['longval'];
    
  
    

    if($fname==""){
        $fname_error="Please enter first name.";
    }
    if($lname==""){
        $lname_error="Please enter last name";
    }
    if($email==""){
        $email_error="Please enter email id";
    }
    if($gender==""){
        $gender_error="Please enter gender";
    }
    if($city==""){
        $city_error="Please enter city";
    }
    if($country==""){
        $country_error="Please enter country";
    }
    if($password==""){
        $password_error="Please enter password";
    }

    include("dbconnect.php");
            $sql = "SELECT * from registration where email='$email' ";
            $retval = mysqli_query($conn ,$sql);
            if(mysqli_num_rows($retval)>0){
                $regg_error="Sorry your email id is already registered.";
            }
            else{
                $filename = $_FILES["uploadfile"]["name"];
                $filename = time().$filename;
                $tempname = $_FILES["uploadfile"]["tmp_name"];
                $folder = './image/' . $filename;
             
                // include("dbconnect.php");
             
                // Get all the submitted data from the form
                // $sql = "update registration set filename='$filename' where email='$user'";
                // $sql = "INSERT INTO registration (filename) VALUES ('$filename') where email= '$user'";
            
                // Execute query
                // mysqli_query($conn, $sql);
            
             
                // Now let's move the uploaded image into the folder: image
                if (move_uploaded_file($tempname, $folder)) {
                    $success="Registration successful, now you can login by clicking on log in button";
                } else {
                    $reg_error="Registration Failed, Try again";
                }
                mysqli_close($conn);
    include("dbconnect.php");    
//             $sql = 'Insert into registration (fname,lname,email,gender,city,country,pass) VALUES
// ("'.$fname.'","'.$lname.'","'.$email.'","'.$gender.'","'.$city.'","'.$country.'","'.$password.'")';
$sql = "Insert into registration (fname,lname,email,gender,city,country,pass,latti,longi,filename) VALUES
('$fname','$lname','$email','$gender','$city','$country','$password','$latt','$longg','$filename')";
    if(mysqli_query($conn,$sql)){
        $success="Registration successful, now you can login by clicking on log in button";
        $fname=null;
        $lname=null;
        $email=null;
        $gender=null;
        $city=null;
        $country=null;
        $password=null;
    }
    else{
        $reg_error="Registration Failed, Try again";
    }
mysqli_close($conn);
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Find ME</title>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.8/css/all.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link rel="stylesheet" href="./css/style.css">
<?php
if($success!=null){?> <style>.success{display: block;}</style>  <?php }
if($reg_error!=null){?> <style>.error{display: block;}</style>  <?php }
if($regg_error!=null){?> <style>.error{display: block;}</style>  <?php }
if($fname_error!=null){?> <style>.fname-error{display: block;}</style>  <?php }
if($lname_error!=null){?> <style>.lname-error{display: block;}</style>  <?php }
if($email_error!=null){?> <style>.email-error{display: block;}</style>  <?php }
if($gender_error!=null){?> <style>.gender-error{display: block;}</style>  <?php }
if($city_error!=null){?> <style>.city-error{display: block;}</style>  <?php }
if($country_error!=null){?> <style>.country-error{display: block;}</style>  <?php }
if($password_error!=null){?> <style>.password-error{display: block;}</style>  <?php }
?>
</head>
<body onload="myGeolocator()">
<div class="container">
<br>  


<div class="row justify-content-center">
<div class="col-md-6">
<div class="card">
<header class="card-header">
    <span class="success"><?php echo $success; ?> </span>
    <span class="error"> <?php echo $reg_error; ?> </span>
	<a href="./login.php" class="float-right btn btn-outline-primary mt-1" style="background-color: green; color:white">Log in</a>
	<h4 class="card-title mt-2">Find Me - Sign up</h4>
    <p>Your Location: <span id="location"></span></p>

</header>
<article class="card-body">
<form action="" method="post" enctype="multipart/form-data">
	<div class="form-row">
		<div class="col form-group">
			<label>First name </label>   
		  	<input type="text" class="form-control" name="fname" placeholder="">
            <span class="fname-error error"><?php echo $fname_error;?></span>
		</div> <!-- form-group end.// -->
		<div class="col form-group">
			<label>Last name</label>
		  	<input type="text" class="form-control" name="lname" placeholder=" ">
              <span class="lname-error error"><?php echo $lname_error;?></span>
		</div> <!-- form-group end.// -->
	</div> <!-- form-row end.// -->
	<div class="form-group">
		<label>Email address</label>
		<input type="email" class="form-control" name="email" id="email" placeholder="">
        <span class="email-error error"><?php echo $email_error;?></span>
		<small class="form-text text-muted">We'll never share your email with anyone else.</small>
	</div> <!-- form-group end.// -->
	<div class="form-group">
			<label class="form-check form-check-inline">
		  <input class="form-check-input" type="radio" name="gender" value="male">
		  <span class="form-check-label"> Male </span>
		</label>
		<label class="form-check form-check-inline">
		  <input class="form-check-input" type="radio" name="gender" value="female">
		  <span class="form-check-label"> Female</span>
		</label>
        <span class="gender-error error"><?php echo $gender_error;?></span>
	</div> <!-- form-group end.// -->
	<div class="form-row">
		<div class="form-group col-md-6">
		  <label>City</label>
		  <input type="text" class="form-control" name="city">
          <span class="city-error error"><?php echo $city_error;?></span>
		</div> <!-- form-group end.// -->
		<div class="form-group col-md-6">
		  <label>Country</label>
		  <select id="inputState" class="form-control" name="country">
		    <option selected=""></option>
		      <option>Uzbekistan</option>
		      <option>Russia</option>
		      <option>United States</option>
		      <option>India</option>
		      <option>Afganistan</option>
		  </select>
          <span class="country-error error"><?php echo $country_error;?></span>
		</div> <!-- form-group end.// -->
	</div> <!-- form-row.// -->
    <div class="form-group">
		<label>Profile Photo</label>
		<input type="file" class="form-control" name="uploadfile" id="image">
        <span class="email-error error"><?php echo $email_error;?></span>
		<small class="form-text text-muted">We'll never share your email with anyone else.</small>
	</div> 
	<div class="form-group">
		<label>Create password</label>
	    <input class="form-control" type="password" name="password">
        <span class="password-error error"><?php echo $password_error;?></span>
	</div> <!-- form-group end.// --> 
    
    
    <div class="col form-group">
		  	<input type="hidden" class="form-control" name="latval"  id="lat" placeholder="">
		  	<input type="hidden" class="form-control" name="longval"  id="long" placeholder="">
		</div> <!-- form-group end.// -->


    <div class="form-group">
        <!-- <button type="submit" class="btn btn-primary btn-block"> Register  </button> -->
        <input type="submit" value="Register" name="register" class="btn btn-primary btn-block" onclick="getLocation()">
    </div> <!-- form-group// -->      
    <small class="text-muted">By clicking the 'Sign Up' button, you confirm that you accept our <br> Terms of use and Privacy Policy.</small>                                          
    <input type="text" name="lat" id="lat" style="display: none;">
    <input type="text" name="long" id="long" style="display: none;">
</form>
</article> <!-- card-body end .// -->
<div class="border-top card-body text-center">Have an account? <a href="">Log In</a></div>
</div> <!-- card.// -->
</div> <!-- col.//-->

</div> <!-- row.//-->


</div> 
<!--container end.//-->

<script>
      let lat = document.getElementById("lat");
      let longi = document.getElementById("long");
      let userLocation = navigator.geolocation;
      function myGeolocator() {
         if(userLocation) {
            userLocation.getCurrentPosition(success);
         } else {
            "The geolocation API is not supported by your browser.";
         }
      }
      function success(data) {
         let lattitud = data.coords.latitude;
         let longitud = data.coords.longitude;
        //  result.innerHTML = "Latitude: "
        //  + lat
        //  + "<br>Longitude: "
        //  + long;
        lat.value=lattitud;
        longi.value=longitud;
      }
   </script>
   <script>
$(document).ready(function(){
    if(navigator.geolocation){
        navigator.geolocation.getCurrentPosition(showLocation);
    }else{ 
        $('#location').html('Geolocation is not supported by this browser.');
    }
});

function showLocation(position){
    var latitude = position.coords.latitude;
    var longitude = position.coords.longitude;
    $.ajax({
        type:'POST',
        url:'getLocation.php',
        data:'latitude='+latitude+'&longitude='+longitude,
        success:function(msg){
            if(msg){
               $("#location").html(msg);
            }else{
                $("#location").html('Not Available');
            }
        }
    });
}
</script>
</body>
</html>
