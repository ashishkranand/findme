<?php
include("dbconnect.php");

$user=$_SESSION["email"];
if($_SESSION["email"]==""){
    header('location:login.php');
    exit;
}
$email=$_GET['email'];   
?>
<?php

if(isset($_POST['sendmsg'])){
    $message=$_POST['message'];
      
            $sql = 'Insert into chat (email,sendto,message) VALUES
("'.$user.'","'.$email.'","'.$message.'")';
    if(mysqli_query($conn,$sql)){
        header('location:chat.php');
        exit();
    }
    else{
        $error="Message not sent, Try again";
    }
        }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chatting - Find Me</title>
    <link rel="shortcut icon" href="./image/logo.png" type="image/x-icon">
    <link rel="stylesheet" href="./css/chatstyle.css">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
	<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
	<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<link rel="stylesheet" href="./css/homestyle.css">
</head>
<body>
<nav class="navbar navbar-expand-md fixed-top top-nav" style="background-color: black;">
		<div class="container">
        <img src="./image/logo.png" alt="" width="5%" style="border-radius:12px;">
			<a class="navbar-brand" href="#"><strong>Find Me</strong></a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"><i class="fa fa-bars" aria-hidden="true"></i></span>
			</button>

			<div class="collapse navbar-collapse" id="navbarSupportedContent">
				<ul class="navbar-nav ml-auto">
					<li class="nav-item active">
						<a class="nav-link" href="./home.php">Home <span class="sr-only">(current)</span></a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="./about.php">About</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="#">Services</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="./profile.php">Profile</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="./logout.php?email=<?php echo $user; ?>">Logout</a>
					</li>
				</ul>
			</div>
		</div>
	</nav>

    <div class="main">
        <div class="center" style="background-color: rgb(1, 37, 59);">
            <div class="heading">
            <?php  
                 

        $sql = "SELECT * FROM registration where email='$email'";
        $retval = mysqli_query($conn ,$sql);
        if(mysqli_num_rows($retval)>0){
            while($row=mysqli_fetch_assoc($retval)){
                // $name=$row['name'];
                // echo $name;
                ?>

            <h1 style="color:white;"><?php echo $row['fname']." "; echo $row['lname'];?></h1>
<?php

            }
        }
        else{
            echo "0 results.";
        }
        
        ?> 
           <!-- <div class="buttons">
           <a href="./logout.php" class="chatbtn">Logout</a>
            <a href="./home.php" class="chatbtn">Home</a>
           </div> -->
            </div>
            <!-- <span style="text-align: right; font-size:larger; padding:1%;background-color:aliceblue;margin-top:5px;color:black;"></span>
        <span style="text-align: left; font-size:larger; padding:1%;background-color:aliceblue;margin-top:5px;color:black;"></span> -->

        <?php  
            // $email=$_GET['email'];        

        $sql = "SELECT * FROM chat where email='$user' or sendto='$email' ";
        $retval = mysqli_query($conn ,$sql);
        if(mysqli_num_rows($retval)>0){
            while($row=mysqli_fetch_assoc($retval)){
             if($row['email']==$email){
                ?>
                    <span style="text-align: left; font-size:larger; padding:1%;background-color:aliceblue;margin-top:5px;color:black;"><?php echo $row['message'];?></span>
                <?php
             }
             else{
                ?>
                <span style="text-align: right; font-size:larger; padding:1%;background-color:aliceblue;margin-top:5px;color:black;"><?php echo $row['message'];?></span>
                <?php
             }

            }
        }
        else{
        }
        mysqli_close($conn);
        
        ?> 


        </div>
            
        
        <form action="" method="post" class="message">
            <textarea name="message" id="" cols="150" rows="2" class="txtarea"></textarea>
            <input type="submit" value="Send" name="sendmsg" class="btn-primary sendbtn">
        </form>
    </div>
</body>
</html>