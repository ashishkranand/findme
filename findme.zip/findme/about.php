<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About us - Find Me</title>
	<link rel="shortcut icon" href="./image/logo.png" type="image/x-icon">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<link rel="stylesheet" href="./css/homestyle.css">
    <link rel="stylesheet" href="./css/aboutstyle.css">
</head>
<body >
<nav class="navbar navbar-expand-md fixed-top top-nav" style="background-color: black;">
		<div class="container">
		<img src="./image/logo.png" alt="" width="5%" style="border-radius:12px;">
			<a class="navbar-brand" href="#"><strong>Find Me</strong></a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"><i class="fa fa-bars" aria-hidden="true"></i></span>
			</button>

			<div class="collapse navbar-collapse" id="navbarSupportedContent">
				<ul class="navbar-nav ml-auto">
					<li class="nav-item ">
						<a class="nav-link" href="./home.php">Home <span class="sr-only">(current)</span></a>
					</li>
					<li class="nav-item active">
						<a class="nav-link " href="./about.php">About</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="#">Services</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="./profile.php">Profile</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="./logout.php">Logout</a>
					</li>
				</ul>
			</div>
		</div>
	</nav>
    <section class="about-section" >
	     <div class="container" >
            <div class="row">
                <div class="col-lg-4 col-md-12 about-text">
                    <div class="section-heading space-overflow">
                        <h3 class="section-title"> <span>  Find Me  </span> </h3>
                    </div>
					<div class="space-t-40 space-b-40" style="color:white">
						<p style="color:white !important;"> If you want to have a peace of mind that the project will be completed with all the features you wanted I would recommend using this team. Merehead is very pleasant to work with, I appreciate Eugene being always available and communicate really well throughout the whole process. If there was something we'd missed he'd just help out and put an end to it. </p>
					</div>
					<a class="custom-btn-nav" href="#" style="color:white !important;">  READ MORE </a>
				</div>
  
                <div class="col-lg-8 col-md-12 about_img space-60 p-0">
                 	<div class="about-image-box">
					  <div class="shape-1"></div>
					  <div class="shape-2"></div>
					  <div class="about-iiner-image-box">
						<div class="layout-33"></div>
					  </div>
					  <img src="./image/about.jpeg">
					</div>
                </div>
            </div>
        </div>
	  </section>
</body>
</html>