
        $().ready(function () {
 
            $("#regform").validate({
               
                // In 'rules' user have to specify all the
               // constraints for respective fields
               // fname, lname, email, phone, gender, city, country, password
                rules: {
                  fname: "required",
                  lname: "required",
                    
                    email: {
                        required: true,
                        email: true
                    },
                    phone:{
                      required:true,
                      number:true,
                      minlength:10,
                      maxlength:10
                    },
                    gender:"required",
                    city:{
                      required:true,
                      minlength:3
                    },
                    country:"required",
                    password: {
                      required: true,
                      minlength: 5
                  },
                },
                // In 'messages' user have to specify message as per rules
                messages: {
                  fname: " Please enter your firstname",
                  lname: " Please enter your lastname",
                    email: {
                        required: " Please enter email",
                        minlength:
                      " Your email must consist of at least 2 characters"
                    },
                    phone:{
                      required:"Please enter phone number",
                      number:"Please enter only numbers",
                      minlength:"Please enter minimum 10 digits",
                      maxlength:"Please enter maximum 10 digits",
                    },
                    gender:"Please choose gender",
                    city:{
                      required:"Please enter city name",
                      minlength:"City name must consist of atleast  3 characters"
                    },
                    country:"Please select country name from dropdown",
                    password: {
                        required: " Please enter a password",
                        minlength:
                      " Your password must be consist of at least 5 characters"
                    }
                }
            })
        });
  