<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Services - Find Me</title>
    <link rel="shortcut icon" href="./image/logo.png" type="image/x-icon">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.1/css/all.min.css" integrity="sha256-2XFplPlrFClt0bIdPgpz8H7ojnk10H69xRqd9+uTShA=" crossorigin="anonymous" />
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
	<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
	<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<link rel="stylesheet" href="./css/homestyle.css">
</head>
<body style="background-color: rgb(1, 37, 59);">
<nav class="navbar navbar-expand-md fixed-top top-nav" style="background-color: black;">
		<div class="container">
		<img src="./image/logo.png" alt="" width="5%" style="border-radius:12px;">
			<a class="navbar-brand" href="#"><strong>Find Me</strong></a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"><i class="fa fa-bars" aria-hidden="true"></i></span>
			</button>

			<div class="collapse navbar-collapse" id="navbarSupportedContent">
				<ul class="navbar-nav ml-auto">
					<li class="nav-item ">
						<a class="nav-link" href="./home.php">Home <span class="sr-only">(current)</span></a>
					</li>
					<li class="nav-item ">
						<a class="nav-link " href="./about.php">About</a>
					</li>
					<li class="nav-item active">
						<a class="nav-link" href="./services.php">Services</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="./profile.php">Profile</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="./logout.php">Logout</a>
					</li>
				</ul>
			</div>
		</div>
	</nav>
<div class="container" style="margin-top:6%;">
    <div class="row align-items-center">
        <div class="col-lg-6 col-md-6 order-2 order-md-1 mt-4 pt-2 mt-sm-0 opt-sm-0">
            <div class="row align-items-center">
                <div class="col-lg-6 col-md-6 col-6">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 mt-4 pt-2">
                            <div class="card work-desk rounded border-0 shadow-lg overflow-hidden">
                                <img src="./image/istockphoto-1385925154-170667a.png" class="img-fluid" alt="Image" />
                                <div class="img-overlay bg-dark"></div>
                            </div>
                        </div>
                        <!--end col-->

                        <div class="col-12">
                            <div class="mt-4 pt-2 text-right">
                                <a href="./home.php" class="btn btn-info">Explore <i class="mdi mdi-chevron-right"></i></a>
                            </div>
                        </div>
                    </div>
                    <!--end row-->
                </div>
                <!--end col-->

                <div class="col-lg-6 col-md-6 col-6">
                    <div class="row">
                        <div class="col-lg-12 col-md-12">
                            <div class="card work-desk rounded border-0 shadow-lg overflow-hidden">
                                <img src="./image/chat.png" class="img-fluid" alt="Image" />
                                <div class="img-overlay bg-dark"></div>
                            </div>
                        </div>
                        <!--end col-->

                        <div class="col-lg-12 col-md-12 mt-4 pt-2">
                            <div class="card work-desk rounded border-0 shadow-lg overflow-hidden">
                                <img src="./image/man.jpeg" class="img-fluid" alt="Image" />
                                <div class="img-overlay bg-dark"></div>
                            </div>
                        </div>
                        <!--end col-->
                    </div>
                    <!--end row-->
                </div>
                <!--end col-->
            </div>
            <!--end row-->
        </div>
        <!--end col-->

        <div class="col-lg-6 col-md-6 col-12 order-1 order-md-2">
            <div class="section-title ml-lg-5">
                <h5 class="text-custom font-weight-normal mb-3" style="border-bottom:4px solid black;color:white;">Our Services</h5>
                <h4 class="title mb-4" style="color:white;">
                    Our mission is to <br />
                    make your life happy with full of love.
                </h4>
                <p class=" mb-0" style="color:white;">You can do a lot of thing by using this website . For example - You can contact with new persons , can filter persons with name, gender and distance and you can also chat with anyone. <br> <span style="color:red">Free of cost , no subscription required.</span></p>
                <br><br>    <span style="font-size: larger;color:white;">You can explore all these by clicking on below buttons</span>
                <div class="row">
                    <div class="col-lg-6 mt-4 pt-2" style="color:white;">
                        <div class="media align-items-center rounded shadow p-3" style="background-color:darkred;">
                            <i class="fa fa-heart h4 mb-0 text-custom"></i>
                            <h6 class="ml-3 mb-0"><a href="./home.php" class="text-light">Make new friends</a></h6>
                        </div>
                    </div>
                    <div class="col-lg-6 mt-4 pt-2" style="color:white;">
                        <div class="media align-items-center rounded shadow p-3" style="background-color:darkred;">
                            <i class="fa fa-user h4 mb-0 text-custom"></i>
                            <h6 class="ml-3 mb-0"><a href="./profile.php" class="text-light">Profile</a></h6>
                        </div>
                    </div>
                    <div class="col-lg-6 mt-4 pt-2" style="color:white;">
                        <div class="media align-items-center rounded shadow p-3" style="background-color:darkred;">
                            <i class="fa fa-user h4 mb-0 text-custom"></i>
                            <h6 class="ml-3 mb-0"><a href="./about.php" class="text-light">Who we are</a></h6>
                        </div>
                    </div>
                    <div class="col-lg-6 mt-4 pt-2" style="color:white;">
                        <div class="media align-items-center rounded shadow p-3" style="background-color:darkred;">
                            <i class="fa fa-book h4 mb-0 text-custom"></i>
                            <h6 class="ml-3 mb-0"><a href="javascript:void(0)" class="text-light">Development</a></h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--end col-->
    </div>
    <!--enr row-->
</div>
</body>
</html>