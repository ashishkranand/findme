<?php
include("dbconnect.php");

$user=$_SESSION["email"];
if($_SESSION["email"]==""){
    header('location:login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home - Find Me</title>
	<link rel="shortcut icon" href="./image/logo.png" type="image/x-icon">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link rel="stylesheet" href="./css/homestyle.css">
<link rel="stylesheet" href="./css/footerstyle.css">
</head>
<body>
<nav class="navbar navbar-expand-md fixed-top top-nav" style="background-color: black;">
	<div class="container">
	<img src="./image/logo.png" alt="" width="5%" style="border-radius:12px;">
		  <a class="navbar-brand" href="#"><strong>Find Me</strong></a>
		  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
		    <span class="navbar-toggler-icon"><i class="fa fa-bars" aria-hidden="true"></i></span>
		  </button>

		  <div class="collapse navbar-collapse" id="navbarSupportedContent">
		    <ul class="navbar-nav ml-auto">
		      <li class="nav-item active">
		        <a class="nav-link" href="./home.php">Home <span class="sr-only">(current)</span></a>
		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="./about.php">About</a>
		      </li>
		      <li class="nav-item">
			  <a class="nav-link" href="./services.php">Services</a>		      </li>
		      <li class="nav-item">
		        <a class="nav-link" href="./profile.php">Profile</a>
		      </li>
              <li class="nav-item">
						<a class="nav-link" href="./logout.php?email=<?php echo $user; ?>">Logout</a>
					</li>
		    </ul>
		  </div>	
	</div>
</nav>

<br><br><br>
<section class="info-section" style="background-color: rgb(1, 37, 59);">
	<div class="container">
		<div class="head-box text-center mb-5"><?php        

        $sql = "SELECT * FROM registration where email='$user'";
        $retval = mysqli_query($conn ,$sql);
        if(mysqli_num_rows($retval)>0){
            while($row=mysqli_fetch_assoc($retval)){
                // $name=$row['name'];
                // echo $name;
                ?>

<h2 style="color: white;">Hi <?php echo $row['fname']; ?> , Connect with new friends</h2>
<?php

            }
        }
        else{
            echo "0 results.";
        }
        mysqli_close($conn);
        
        ?> 
			<h6 style="color: white;" class="text-underline-primary">Explore website to know more</h6>
            <br><h3 style="color: white;">Filter by <span>
			<div class="filter" style="display:inline-block">
				<form action="./filterhome.php" method="post" >
							<select name="filter" id="">
								<option value="male">Male </option>
								<option value="female">FeMale </option>
							</select>
							<input type="submit" class="btn btn-primary" value="Search" name="search">
						</form>
				</div>
						<div class="filter" style="display:inline-block">
							
						<form action="./filterhomebydistance.php" method="post">
							<p style="color:white;">Search by km: <output id="value" style="color:white;"></output></p>
							<input id="pi_input" type="range" min="0" max="2000" step="any" name="filtbydist" />

							<input type="submit" class="btn btn-primary" value="Search" name="search">
						</form>
						
						</div>
						<div class="filter" style="display:inline-block">
							<form action="./filterhomebyname.php" method="post" >
							<input type="text" name="filtname" id="">
							<input type="submit" class="btn btn-primary" value="Search" name="search">
						</form>
						
						
						</div>

            </span></h3>
		</div>
		<div class=" mt-4">
			<div class="row" style="margin-left: 10%;">
				
				
                <?php   
				include("dbconnect.php");
				$sql = "SELECT * FROM registration where email='$user'";
				$retval = mysqli_query($conn, $sql);
				if (mysqli_num_rows($retval) > 0) {
					while ($row = mysqli_fetch_assoc($retval)) {
						$userlat = $row['latti'];
						$userlong = $row['longi'];
					}
				} else {
					echo "0 results.";
				}
				mysqli_close($conn);

				include("dbconnect.php"); 
                $filt=$_POST['filter'];      
        include("dbconnect.php");
        $sql = "SELECT * FROM registration where gender='$filt'";
        $retval = mysqli_query($conn ,$sql);
        if(mysqli_num_rows($retval)>0){
            while($row=mysqli_fetch_assoc($retval)){
                // $name=$row['name'];
                // echo $name;
				if($row['email']==$user){

				}
				else{

				
                ?>

<div class="col-lg-3 col-md-4 col-sm-6 m-3" style="background-color: silver; border-radius:10px;">
									<div class="text-center mb-3 p-lg-3">
									<img class="img" src="./image/<?php echo $row['filename']; ?>" onerror="this.src='./image/back.png';" alt="Not available" width="160px" style="border-radius: 10px;">
										<h3 style="color:black"><?Php echo $row['fname'];
																echo " " . $row['lname']; ?></h3>
										<p class="px-4" style="color:black">From :- <?Php echo $row['city']; ?></p>
										<?php
										$latitudeFrom = $userlat;
										$longitudeFrom = $userlong;
										$latitudeTo = $row['latti'];
										$longitudeTo = $row['longi'];

										//Calculate distance from latitude and longitude
										$theta = $longitudeFrom - $longitudeTo;
										$dist = sin(deg2rad($latitudeFrom)) * sin(deg2rad($latitudeTo)) +  cos(deg2rad($latitudeFrom)) * cos(deg2rad($latitudeTo)) * cos(deg2rad($theta));
										$dist = acos($dist);
										$dist = rad2deg($dist);
										$miles = $dist * 60 * 1.1515;

										$distance = ($miles * 1.609344) . ' km';
										?>
										<p class="px-4" style="color:black">Distance :- <?Php echo (int)$distance; ?></p>

										<a href="./chat.php?email=<?php echo $row['email']; ?>" class="btn btn-danger">Send Message</a>
										
									</div>
								</div>
<?php
				}
            }
        }
        else{
            echo "0 results.";
        }
        mysqli_close($conn);
        
        ?> 

			</div>
		</div>
	</div>
</section>

<footer >
     <div class="container-fluid bg-primary py-3" >
    <div class="container">
      <div class="row">
        <div class="col-md-7">
            <div class="row py-0">
          <div class="col-sm-1 hidden-md-down">
              <a class="bg-circle bg-info" href="#">
                <i class="fa fa-2x fa-fw fa-address-card" aria-hidden="true "></i>
              </a>
            </div>
            <div class="col-sm-11 text-white">
                <div><h4> Contact Us</h4>
                    <p> <span class="header-font">F</span>ind<span class="header-font">M</span>e.com</p>
                </div>
            </div>
            </div>
        </div>
        <div class="col-md-5">
          <div class="d-inline-block">
            <div class="bg-circle-outline d-inline-block" style="background-color:#3b5998">
              <a href="https://www.facebook.com/"><i class="fa fa-2x fa-fw fa-facebook text-white"></i>
		</a>
            </div>
            <div class="bg-circle-outline d-inline-block" style="background-color:#4099FF">
              <a href="https://twitter.com/">
                <i class="fa fa-2x fa-fw fa-twitter text-white"></i></a>
            </div>

            <div class="bg-circle-outline d-inline-block" style="background-color:#0077B5">
              <a href="https://www.linkedin.com/company/">
                <i class="fa fa-2x fa-fw fa-linkedin text-white"></i></a>
            </div>
            <div class="bg-circle-outline d-inline-block" style="background-color:#d34836">
              <a href="https://www.google.com/">
                <i class="fa fa-2x fa-fw fa-google text-white"></i></a>
            </div>
          </div>
        </div>
      </div>
    </div>
    </div>
</footer>
    <!--/.footer-->
<p class="text-center"> Copyright © Footer Mywebsite Plugin 2014. All right reserved. </p>
    <!--/.footer-bottom--> 

	<script>
	const value = document.querySelector("#value")
const input = document.querySelector("#pi_input")
value.textContent = input.value
input.addEventListener("input", (event) => {
  value.textContent = parseInt(event.target.value);
})
</script>
</body>
</html>