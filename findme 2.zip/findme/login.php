<?php
$email_error=null;
$password_error=null;

if(isset($_POST['login'])){
    $uname=$_POST['emailorphone'];
    $password=$_POST['password'];
    if( $uname==""){
        $email_error="Email is blank";
    } 
    else if($password == ""){
        
            $password_error="Password is blank";
    }
        
        else{
            include("dbconnect.php");
            $password=$_POST['password'];
            $sql = "SELECT * from registration where email='$uname' or phone='$uname' and pass='$password'";
            $retval = mysqli_query($conn ,$sql);
            if(mysqli_num_rows($retval)>0){
                header('location:home.php');
                
        $sql = "SELECT * FROM registration where email='$uname' or phone='$uname'";
        $retval = mysqli_query($conn ,$sql);
        if(mysqli_num_rows($retval)>0){
            while($row=mysqli_fetch_assoc($retval)){
             $email=$row['email'];

            }
        }
        else{
        }
                $_SESSION["email"] = $email;
                
                $sql = "Update registration set status = 1 where email='$email'";
    if(mysqli_query($conn,$sql)){
    }

                exit();

            }
            else{
                $login_error = "Login failed";

            }
mysqli_close($conn);
        }
    }
        ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Find Me</title>
    <link rel="shortcut icon" href="./image/logo.png" type="image/x-icon">
    <link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<link rel="stylesheet" href="./css/styles.css">
<script src="./script/logscript.js"></script>
<script src="./script/form-validation.js"></script>
<link rel="stylesheet" href="./css/style.css">
<?php
if($email_error!=null){?> <style>.error{display: block;}</style>  <?php }
if($password_error!=null){?> <style>.error{display: block;}</style>  <?php }
?>
</head>
<body>

<div class="container" style="padding:5%;margin-top:5%;border-radius:10px;">

<div class="row" style="margin-top:20px">
    <div class="col-xs-12 col-sm-8 col-md-6 col-sm-offset-2 col-md-offset-3">
		<form role="form" id="form" action="" method="post">
			<fieldset>
                
				<h2 style="background-color:darkblue;color:white;border-radius:5px;padding:2%;"> <img src="./image/logo.png" alt="" width="10%" style="border-radius:12px;margin-right:3%;">Find Me - Login</h2>
				<hr class="colorgraph">
				<div class="form-group">
                    <p><input type="text" name="emailorphone" id="emailorphone" class="form-control input-lg" placeholder="Email id or Phone number"></p>
                    <span class="error"><?php echo $email_error; ?></span>
				</div>
				<div class="form-group">
                <p>    <input type="password" name="password" id="password" class="form-control input-lg" placeholder="Password"></p>
                <span class="error"><?php echo $password_error; ?></span>
				</div>
				<span class="button-checkbox">
                    <input type="checkbox" name="remember_me" id="remember_me" checked="checked" class="hidden">
					<a href="./forget-password.php" class="btn btn-link pull-right">Forgot Password?</a>
				</span>
				<hr class="colorgraph">
				<div class="row">
					<div class="col-xs-6 col-sm-6 col-md-6" style="margin-top: 1.5%;">
                        <input type="submit" class="btn btn-lg  btn-block" value="Sign In" name="login" style="background-color: rgb(222, 49, 99);color:white">
					</div>
					<div class="col-xs-6 col-sm-6 col-md-6">
						<a href="./index.php" class="btn btn-lg btn btn-primary btn-block" style="background-color: #2E85F5;">Register</a>
					</div>
				</div>
			</fieldset>
		</form>
	</div>
</div>

</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>

</body>
</html>
